package com.scu.practice;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;

public class MyRequestAttributeListener implements
		ServletRequestAttributeListener {

	public void attributeAdded(ServletRequestAttributeEvent servletRequestAttributeEvent) {
		System.out.println("requestAttribute_attributeAdded: "+servletRequestAttributeEvent.getName());

	}

	public void attributeRemoved(ServletRequestAttributeEvent servletRequestAttributeEvent) {
		System.out.println("requestAttribute_attributeRemoved: "+servletRequestAttributeEvent.getName());

	}

	public void attributeReplaced(ServletRequestAttributeEvent servletRequestAttributeEvent) {
		System.out.println("requestAttribute_attributeReplaced: "+servletRequestAttributeEvent.getName());

	}

}
