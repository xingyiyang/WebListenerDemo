package com.scu.practice;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

public class MyHttpSessionAttributeListener implements
		HttpSessionAttributeListener {

	public void attributeAdded(HttpSessionBindingEvent httpSessionBindingEvent) {
		System.out.println("sessionAttribute_attributeAdded: "+httpSessionBindingEvent.getName());

	}

	public void attributeRemoved(HttpSessionBindingEvent httpSessionBindingEvent) {
		System.out.println("sessionAttribute_attributeRemoved: "+httpSessionBindingEvent.getName());

	}

	public void attributeReplaced(HttpSessionBindingEvent httpSessionBindingEvent) {
		System.out.println("sessionAttribute_attributeReplaced: "+httpSessionBindingEvent.getName());

	}

}
