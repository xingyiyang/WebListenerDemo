package com.scu.practice;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;

public class MyServletAttributeListener implements
		ServletContextAttributeListener {

	public void attributeAdded(ServletContextAttributeEvent servletContextAttributeEvent) {
		System.out.println("servletContext_attributeAdded: "+servletContextAttributeEvent.getName());

	}

	public void attributeRemoved(ServletContextAttributeEvent servletContextAttributeEvent) {
		System.out.println("servletContext_attributeRemoved: "+servletContextAttributeEvent.getName());

	}

	public void attributeReplaced(ServletContextAttributeEvent servletContextAttributeEvent) {
		System.out.println("servletContext_attributeReplaced: "+servletContextAttributeEvent.getName());

	}

}
