package com.scu;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class MyServletRequestListener implements ServletRequestListener {

	public void requestInitialized(ServletRequestEvent servletRequestEvent) {
		String name = servletRequestEvent.getServletRequest().getParameter("name");
		System.out.println("requestInitialized: name = "+name);

	}
	
	public void requestDestroyed(ServletRequestEvent servletRequestEvent) {
		String name = servletRequestEvent.getServletRequest().getParameter("name");
		System.out.println("requestDestroyed: name = "+name);

	}

}
