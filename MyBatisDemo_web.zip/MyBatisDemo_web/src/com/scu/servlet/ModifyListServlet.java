package com.scu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scu.bean.Message;
import com.scu.service.MaintainService;

public class ModifyListServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//�����������ݵı���
		req.setCharacterEncoding("utf-8");
		//����ҳ�洫������ֵ
		String id = req.getParameter("id");
		String command = req.getParameter("command");
		String description = req.getParameter("description");
		String content = req.getParameter("content");
		Message message = new Message();
		message.setId(Integer.valueOf(id));
		message.setCommand(command);
		message.setDescription(description);
		message.setContent(content);
		//��ѯ��Ϣ�б�������ҳ��
		MaintainService maintainService = new MaintainService();
		maintainService.updateList(message);		
		
		//��תҳ��
		req.getRequestDispatcher("/ListServlet.action").forward(req, resp);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(req, resp);
	}
}
