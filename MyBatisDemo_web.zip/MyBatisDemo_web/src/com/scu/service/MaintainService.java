package com.scu.service;

import java.util.ArrayList;
import java.util.List;

import com.scu.bean.Message;
import com.scu.dao.MessageDao;

/**
 * @author xing
 * ά�����ҵ���ܣ���ɾ�Ĳ�
 */
public class MaintainService {
	
	
	/**
	 * ��ѯ�б�
	 */
	public List<Message> queryMessageList(){
		MessageDao messageDao = new MessageDao();
		return messageDao.queryList();	
	}
	/**
	 * @param command
	 * @param description
	 * @return ����ָ�������������ѯ
	 */
	public List<Message> SearchList(String command, String description){
		MessageDao messageDao = new MessageDao();
		return messageDao.searchList(command, description);	
	}
	
	/**
	 * ��������
	 */
	public void addOne(Message message){
		MessageDao messageDao = new MessageDao();		
		messageDao.addOne(message);
	}
	
	/**
	 * ����ɾ��
	 */
	public void deleteOne(String id){
		if(id != null && !"".equals(id.trim())){
			MessageDao messageDao = new MessageDao();
			messageDao.deleteOne(Integer.valueOf(id));
		}	
	}
	
	/**
	 * ����ɾ��
	 */
	public void deleteBatch(String[] ids){
		MessageDao messageDao = new MessageDao();
		List<Integer> idList = new ArrayList<Integer>();
		for(String id:ids){
			idList.add(Integer.valueOf(id));
		}
		messageDao.deleteBatch(idList);	
	}
	
	public void updateList(Message message){
		MessageDao messageDao = new MessageDao();
		messageDao.updateList(message);
	}

}
