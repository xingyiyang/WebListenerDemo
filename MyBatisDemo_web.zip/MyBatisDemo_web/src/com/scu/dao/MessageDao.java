package com.scu.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.scu.bean.Message;
import com.scu.db.DBAccess;

/**
 * ��message����ص����ݿ��ѯ
 * 
 * @author xing
 * 
 */
public class MessageDao {

	/**
	 * ��ѯ��Ϣ�б�
	 * @param command
	 * @param description
	 * @return 
	 */
	public List<Message> queryList(){
		DBAccess dbAccess = new DBAccess();
		List<Message> messageList = new ArrayList<Message>();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();
			
			//ͨ��sqlSessionִ��sql���
			messageList = sqlSession.selectList("Message.queryList");
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sqlSession!=null){
				sqlSession.close();
			}
		}
		return messageList;
		
	}
	
	/**
	 * ���ݲ�ѯ������ѯ��Ϣ�б�
	 * @param command
	 * @param description
	 * @return 
	 */
	public List<Message> searchList(String command, String description){
		DBAccess dbAccess = new DBAccess();
		List<Message> messageList = new ArrayList<Message>();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();
			Message message = new Message();
			message.setCommand(command);
			message.setDescription(description);
			//ͨ��sqlSessionִ��sql���
			messageList = sqlSession.selectList("Message.searchList",message);
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sqlSession!=null){
				sqlSession.close();
			}
		}
		return messageList;
		
	}
	
	/**
	 * ��������
	 */
	public void addOne(Message message) {
		DBAccess dbAccess = new DBAccess();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();			
			//ͨ��sqlssesionִ��sql���			
			sqlSession.insert("Message.addOne",message);			
			sqlSession.commit();
			
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		
	}
	
	/**
	 * ����ɾ��
	 */
	public void deleteOne(int id){
		DBAccess dbAccess = new DBAccess();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();			
			//ͨ��sqlssesionִ��sql���
			sqlSession.delete("Message.deleteOne",id);
			sqlSession.commit();
			
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sqlSession != null){
				sqlSession.close();
			}
		}
	}
	
	/**
	 * ����ɾ���б�
	 */
	public void deleteBatch(List<Integer> ids){
		DBAccess dbAccess = new DBAccess();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();
			
			//ͨ��sqlssesionִ��sql���
			sqlSession.delete("Message.deleteBatch",ids);
			//�ύ����
			sqlSession.commit();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(sqlSession != null){
				sqlSession.close();
			}
		}
	}
	
	/**
	 * �޸�����
	 * @param message
	 */
	public void updateList(Message message){
		DBAccess dbAccess = new DBAccess();
		SqlSession sqlSession = null;
		try {
			sqlSession = dbAccess.getSqlSession();			
			//ͨ��sqlssesionִ��sql���
			sqlSession.update("Message.updateList",message);	
			sqlSession.commit();
			
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sqlSession != null){
				sqlSession.close();
			}
		}
	}
	
	/**
	 * ���ݲ�ѯ������ѯ��Ϣ�б�
	 */
//	public List<Message> queryMessageList(String command, String description) {
//		
//		// �Ѳ�ѯ�Ľ����װ��List����
//		List<Message> messageList = new ArrayList<Message>();
//		try {
//
//			Class.forName("com.mysql.jdbc.Driver");
//			Connection con = DriverManager
//					.getConnection(
//							"jdbc:mysql://127.0.0.1:3306/micro_message?characterEncoding=utf8",
//							"root", "123456");
//			StringBuilder sql = new StringBuilder(
//					"select id,command,description,content from message where 1=1");
//			List<String> paramList = new ArrayList<String>();
//			if (command != null && !"".equals(command.trim())) {
//				sql.append(" and command like '%' ? '%'");
//				paramList.add(command);
//			}
//			if (description != null && !"".equals(description.trim())) {
//				sql.append(" and description like '%' ? '%'");
//				paramList.add(description);
//			}
//			PreparedStatement stmt = con.prepareStatement(sql.toString());
//			for (int i = 0; i < paramList.size(); i++) {
//
//				// setString�����Ǹ���������ֵ
//				stmt.setString(i + 1, paramList.get(i));
//			}
//			ResultSet rs = stmt.executeQuery();
//
//			//������ѯ���
//			while (rs.next()) {
//				Message message = new Message();
//				message.setId(rs.getInt("id"));
//				message.setCommand(rs.getString("command"));
//				message.setDescription(rs.getString("description"));
//				message.setContent(rs.getString("content"));
//				messageList.add(message);
//			}
//			
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return messageList;
//
//	}

}
