/**
 * ����ɾ��
 */
function deleteBatch(basePath){
	$("#mainForm").attr("action",basePath+"DeleteBatchServlet.action");
	$("#mainForm").submit();
}

/**
 * ��ѯ��Ϣ
 */
function searchList(basePath){
	$("#mainForm").attr("action",basePath+"SearchServlet.action");
	$("#mainForm").submit();
}
