package com.scu.employee.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * ���ŵ�ʵ��
 * 
 * @author xing
 * 
 */
public class Department {

	private Integer did;
	private String dname;
	private String ddesc;

	//Ա���ļ���
	private Set<Employee> employees = new HashSet<Employee>();
	
	public Integer getDid() {
		return did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDdesc() {
		return ddesc;
	}

	public void setDdesc(String ddesc) {
		this.ddesc = ddesc;
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}

}
